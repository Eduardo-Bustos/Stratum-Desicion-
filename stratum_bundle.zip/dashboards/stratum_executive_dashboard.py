
import streamlit as st
st.title("STRATUM Dashboard")
st.write("System running")
